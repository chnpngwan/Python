# import tkinter

# top=tkinter.Tk()
# label=tkinter.Label(top,text='Hello Python!', relief='ridge')
# label.pack()
# top.mainloop()

# import tkinter
# top=tkinter.Tk()
# top.title('图形用户界面')
# top.mainloop()

# import tkinter
# top=tkinter.Tk()
# top.title('python GUI')
# #下面是创建的第1个按钮对象butt1
# butt1=tkinter.Button(top,width=10,bg='red',fg='blue',bd=8,text='Welcome',
# 	anchor='center',font=('Arial',24,'bold'))
# butt1.pack(pady=20)
# #下面是创建的第2个按钮对象butt2
# butt2=tkinter.Button(top,width=15,bd=6,text='Eliminate',anchor='s',
# 	font=('Levenim MT',16,'italic'))
# butt2.pack(pady=15)
# #下面是创建的第3个按钮对象butt3
# butt3=tkinter.Button(top,width=10,bd=4,text='Return',anchor='e',
# 	font=('Verdana',18,'italic','bold'),relief='groove',cursor='cross arrow')
# butt3.pack(pady=10)
# top.mainloop()

# import tkinter
# top=tkinter.Tk()
# top.title('python GUI')
# but1=tkinter.Button(top,text='Return',font=('Verdana',16,
# 	'italic','bold'),fg='red',command=top.quit)
# but1.pack(pady=15)
# top.mainloop()

import tkinter 
top=tkinter.Tk()
top.title('python GUI')
ent1=tkinter.Entry(top,font=('Arial',16,'italic','bold'),fg='Red',relief='ridge',bd=5)
ent1.pack(padx=10,pady=20)
ent2=tkinter.Entry(top,font=('Arial',16,'italic','bold'),	fg='Red',relief='ridge',bd=3,state='disabled')
ent2.pack(padx=10,pady=30)
top.mainloop()



