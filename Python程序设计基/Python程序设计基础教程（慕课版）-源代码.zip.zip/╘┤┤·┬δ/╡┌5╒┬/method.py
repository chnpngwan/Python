def add():
	x = 1 + 2
	return x

print(type(add))

def anwser(x,y):
	return x,y,x+y,x*y,x/y

print(type(anwser(1,2)))