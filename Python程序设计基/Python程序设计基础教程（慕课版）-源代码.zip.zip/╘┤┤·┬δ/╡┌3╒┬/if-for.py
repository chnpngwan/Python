'''
age = input("请输入年龄：")
print(age)
age = int(age)
age1 = age + 10
print(age1)
'''

num = input("please enter:")
num = int(num)
if num < 0:
	num = -num
	print('---')

print(num)
