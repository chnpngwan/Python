import math
a=int(input('请输入第一个整数！'))
b=int(input('请输入第二个整数！'))
c=int(input('请输入第三个整数！'))
d=b*b-4*a*b
if d>=0:
	p=-b/(2*a)
	q=math.sqrt(d)/(2*a)
	x1=p+q
	x2=p-q
	print('第一个根：x1=%d; 第二个根：x2=%d\n'%(x1,x2))
else:
	print('没有根存在!')
