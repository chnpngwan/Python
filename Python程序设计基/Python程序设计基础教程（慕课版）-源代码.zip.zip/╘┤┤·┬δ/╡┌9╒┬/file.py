# file = open('C:\\project\\第9章\\remark.txt','a+')
# file.write('再来一次再次重新写入文件')

# import tkinter as tk
# top=tk.Tk()
# top.title('python GUI')
# top.geometry('310x200+10+10')
# txt1=tk.Text(top,bd=2,fg='Red',relief='sunken', width=26,height=5,font=('隶书',14))
# txt1.pack(side='top',pady=20)
# txt1.insert('end','在此显示文件messg1里的内容\n')
# def callback():#回调函数
# 	fp=open('C:\\project\\第9章\\remark.txt','w')
# 	fp.write('Good morning, Mr.Python!  Good afternoon, Mr.Python! ')
# 	fp=open('C:\\project\\第9章\\remark.txt','r')
# 	str1=fp.read()
# 	txt1.insert('end',str1)
# 	fp.close()
# btn1=tk.Button(top,text='Show',width=8, fg='red',font=('Verdana',14,'bold','italic'),command=callback)
# btn1.pack(side='left',padx=23)
# btn2=tk.Button(top,text='Return',width=8, fg='red',font=('Verdana',14,'bold','italic'),command=quit)
# btn2.pack(side='left',padx=5)
# top.mainloop()


import tkinter as tk
top=tk.Tk()
top.title('python GUI')
top.geometry('320x200+10+10')

txt1=tk.Text(top,bd=2,fg='Red',relief='sunken',
	width=30,height=6,font=('隶书',14))
txt1.pack(side='top',pady=10)
txt1.insert('end','在此逐行显示文件messg1里的内容\n')

fp=open('C:\\project\\第9章\\messg1.txt','w')
fp.write('Good morning, Mr.Python!\n')
fp.write('Good afternoon, Mr.Python!\n')
fp.write('Good evening, Mr.Python!\n')
fp.write('Good bye, Mr.Python!\n')
fp.close()
i=0
def reado():
	global i
	fp=open('C:\\project\\第9章\\messg1.txt','r')
	while True:
		i+=1
		line=fp.readline()
		if line=='':
			break
		else:
			txt1.insert('end',str(i)+'. '+line)
	fp.close()	
btn1=tk.Button(top,text='按行读出',width=8,
	fg='red',font=('Verdana',14,'bold','italic'),command=reado)
btn1.pack(side='left',padx=23)
btn2=tk.Button(top,text='退出',width=8,
	fg='red',font=('Verdana',14,'bold','italic'),command=quit)
btn2.pack(side='left',padx=5)
top.mainloop()

