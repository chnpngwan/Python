first_name='tom'
print(first_name)
