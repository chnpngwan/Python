first_name="zhangsan"
last_name="lisi"
print(first_name)
print(last_name)
print(first_name+"."+last_name)